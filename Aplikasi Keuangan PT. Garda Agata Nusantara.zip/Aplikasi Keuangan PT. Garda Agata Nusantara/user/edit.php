<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location: ../dist/index.php?pesan=belum_login");
}
require_once '../function/koneksi.php';
$id_login = $_GET['id_login'];

$sql = "SELECT * FROM admin WHERE id_login = '$id_login'";
$query = mysqli_query($koneksi, $sql);
$row = mysqli_fetch_assoc($query);

$username = $row['username'];
$password = $row['password'];
$level = $row['level'];



if (isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = $_POST['level'];
    header("location: user.php?data=edit");
}

$queryUpdate = "UPDATE admin SET username = '$username',  password = '$password', level= '$level' WHERE id_login= '$id_login' ";

$test = mysqli_query($koneksi, $queryUpdate);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <link href="../dist/css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php
    $cari = '';
    $halaman = 'user';
    $level = isset($_SESSION['level']) ? $_SESSION['level'] : false;
    include '../sidebar.php'
    ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Data User</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"></li>
                </ol>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table mr-1"></i>
                    </div>

                    <div class="card-body">
                        <form action="" method="post">

                            <div class="form-group">
                                <label>Username</label>
                                <input required type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Password</label>
                                <input required type="password" name="password" class="form-control" value="<?php echo $row['password']; ?>" required>
                            </div>

                            <!-- <div class="form-group">
                                    <label>Level</label>
                                    <input required type="text" name="level" class="form-control" value="<?php echo $row['level']; ?>" required>
                                </div> -->
                            <div class="form-group">
                                <label>Level</label><br>
                                <input required type="radio" name="level" value="admin" <?php echo ($row['level'] == 'admin') ? "checked" : '' ?> required> Admin
                                <input style="margin-left: 20px ;" type="radio" name="level" value="user" <?php echo ($row['level'] == 'user') ? "checked" : '' ?> required> User
                            </div>

                            <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Reka Meisa</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../dist/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="../dist/assets/demo/chart-area-demo.js"></script>
    <script src="../dist/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="../dist/assets/demo/datatables-demo.js"></script>
</body>

</html>