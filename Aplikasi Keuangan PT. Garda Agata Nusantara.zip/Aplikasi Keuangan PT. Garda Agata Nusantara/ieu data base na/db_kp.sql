-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 03 Mar 2022 pada 07.52
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_login` int(11) NOT NULL,
  `level` enum('admin','superadmin','','') NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_login`, `level`, `username`, `password`) VALUES
(1, 'admin', 'staff', 'staff'),
(2, 'superadmin', 'admin', 'admin'),
(4, 'admin', 'staff2', 'staff2'),
(5, 'admin', 'septa', '123'),
(6, 'admin', 'jamil', 'jamil'),
(7, 'admin', 'rafli', 'rafli');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_barang`
--

CREATE TABLE `data_barang` (
  `id_barang` int(11) NOT NULL,
  `kode_barang` varchar(12) NOT NULL,
  `id_login` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `quantity` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `saldo` bigint(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_barang`
--

INSERT INTO `data_barang` (`id_barang`, `kode_barang`, `id_login`, `nama_barang`, `quantity`, `tanggal`, `saldo`) VALUES
(13, 'A01', 2, 'SPRING SET BATTERY', 1, '2022-03-09', 50000),
(14, 'A02', 2, 'Kamera', 1, '2022-03-09', 1000000),
(15, 'A03', 2, 'Jus', 10, '2022-03-09', 100000),
(16, 'A04', 2, 'Laptop', 1, '2022-03-10', 5000000),
(17, 'A05', 2, 'Buku', 12, '2022-03-10', 200000),
(19, 'A07', 2, 'Naga', 1, '2022-03-03', 200000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_jadi`
--

CREATE TABLE `data_jadi` (
  `id_jadi` int(11) NOT NULL,
  `kode_barang` varchar(12) NOT NULL,
  `id_login` int(11) NOT NULL,
  `nama_barang` varchar(200) NOT NULL,
  `quantity` int(10) NOT NULL,
  `tanggal` date NOT NULL,
  `saldo` bigint(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_jadi`
--

INSERT INTO `data_jadi` (`id_jadi`, `kode_barang`, `id_login`, `nama_barang`, `quantity`, `tanggal`, `saldo`) VALUES
(13, 'B01', 2, 'Kaos', 3, '2022-03-16', 150000),
(14, 'B02', 2, 'Semprot', 2, '2022-03-17', 500000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_login`);

--
-- Indeks untuk tabel `data_barang`
--
ALTER TABLE `data_barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `id_login` (`id_login`);

--
-- Indeks untuk tabel `data_jadi`
--
ALTER TABLE `data_jadi`
  ADD PRIMARY KEY (`id_jadi`),
  ADD KEY `id_login` (`id_login`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `data_barang`
--
ALTER TABLE `data_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `data_jadi`
--
ALTER TABLE `data_jadi`
  MODIFY `id_jadi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
