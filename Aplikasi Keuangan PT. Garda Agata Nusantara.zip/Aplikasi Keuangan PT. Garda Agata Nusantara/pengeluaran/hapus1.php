<?php  
	require_once '../function/koneksi.php';


	$id_jadi = $_GET['id_jadi'];

	mysqli_query($koneksi,"DELETE FROM data_jadi WHERE id_jadi = '$id_jadi'") or die( "Gagal menghapus database");


		header("location:datajadi.php");
