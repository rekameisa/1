<?php
session_start();
$usern = $_SESSION['username'];
$level = $_SESSION['level'];
require_once 'function/koneksi.php';


$sql_mentah = "SELECT sum(saldo) AS jumlah FROM data_barang";
$query_mentah = mysqli_query($koneksi, $sql_mentah);
$hasil_mentah = mysqli_fetch_assoc($query_mentah);

$sql_jadi = "SELECT sum(saldo) AS jumlah FROM data_jadi";
$query_jadi = mysqli_query($koneksi, $sql_jadi);
$hasil_jadi = mysqli_fetch_assoc($query_jadi);

$profit =  $hasil_mentah['jumlah'] - $hasil_jadi['jumlah'];

?>
<?php
//$id = $_SESSION['id_login'];

if ($_SESSION['status'] != "login") {
    header("location: dist/index.php?pesan=belum_login");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <link href="dist/css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>

    <style>
        .jarak {
            margin: 10px;
        }

        .padd {
            padding: 10px;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <?php
    $cari = '';
    $halaman = 'dashboard';
    include 'sidebar.php';
    ?>
    <div id="layoutSidenav_content">
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="mt-4">Dashboard</h1>
                </ol>
            </div>

            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"></li>
            </ol>


            <div class="card mb-4">
                <div class="card-header">

                    <div class="row" align="center">

                        <div class="col-xl-4 col-md-2 mb-2">
                            <div class="card border-left-primary shadow h-100 py-3 jarak">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Data Pendapatan</div><br>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo rupiah($hasil_mentah['jumlah']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-2 mb-2">
                            <div class="card border-left-success shadow h-100 py-3 jarak">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1 fa-align-center">
                                                Data Pengeluaran</div><br>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo rupiah($hasil_jadi['jumlah']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-2 mb-2">
                            <div class="card border-left-success shadow h-100 py-3 jarak">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-uppercase mb-1" style="color: purple;">
                                                Profit</div><br>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo rupiah($profit); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="card-body">
                    <h4>Visi Garda</h4>
                    <p align="justify">Garda Pest Control memiliki visi “Memberikan Layanan Jasa Pengendalian Hama yang Cepat dan Berkualitas 24 Jam di seluruh Indonesia dengan Menjaga Keamanan Bagi Lingkungan, Konsumen dan Teknisi.”</p>

                    <h4>Misi Garda</h4>
                    <ol style="text-align: justify;">
                        <li>Melakukan metode pekerjaan pengendalian hama sesuai dengan Standard Operational Procedure (SOP) dan penggunaan bahan kimia yang mengacu pada peraturan pemerintah dari suku dinas Kesehatan dan Komisi pestisida Republik Indonesia.</li>
                        <li>Memberikan pelayanan service yang didasarkan pada aplikasi tepat dosis, tepat hama sasaran, dan tepat metode kerja untuk setiap akurasi pekerjaannya.</li>
                        <li>Mengedepankan solusi less chemical dengan kualitas sanitasi, tindakan preventif dan eksklusi yang baik guna mendukung program pencegahan pencemaran lingkungan.</li>
                    </ol>
                </div>
            </div>
        </div>


        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Reka Meisa</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>

    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="dist/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="dist/assets/demo/chart-area-demo.js"></script>
    <script src="dist/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="dist/assets/demo/datatables-demo.js"></script>
</body>

</html>