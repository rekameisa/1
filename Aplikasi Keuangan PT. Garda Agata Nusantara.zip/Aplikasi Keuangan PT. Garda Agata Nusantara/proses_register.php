<?php  
	
	require_once 'function/koneksi.php';

	$level = "user";
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "INSERT INTO admin(level, username, password) VALUES('$level', $username', '$password') ";
    $query = mysqli_query($koneksi, $sql);

?>