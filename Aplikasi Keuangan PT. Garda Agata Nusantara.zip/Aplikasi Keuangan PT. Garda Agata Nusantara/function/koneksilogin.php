<?php

$koneksilogin = mysqli_connect("localhost","root","","db_kp");

if (mysqli_connect_errno()) {

	echo "database gagal : " . mysqli_connect_error();
	
}





  ?>