<?php 

	$host = '127.0.0.1';
	$user = 'root';
	$password = '';
	$db = 'db_kp';

	$koneksi = mysqli_connect($host, $user, $password, $db) or die( "Gagal menghubungkan database");

function rupiah($uang){
	$rupiah='Rp. '. number_format($uang,2,',','.');
	return $rupiah;
}
